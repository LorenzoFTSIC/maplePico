# Main controller for template matching and determining input pattern
# Inputs get sent to pi pico then returned
from comms.pico import Pico
from vision.screenshot import screenshot
from vision.templateMatcher import matchMyTemplate
from classes.ds import createDemonSlayer
import config
import time



def main():

    pico = Pico()
    
    demonSlayer = createDemonSlayer()
    rotation = demonSlayer.rotations["tpFarm"]

    while True:
        image = screenshot(config.SCREEN_REGION)
        




        # small delay 
        time.sleep(1)



if __name__ == "__main__":
    main()